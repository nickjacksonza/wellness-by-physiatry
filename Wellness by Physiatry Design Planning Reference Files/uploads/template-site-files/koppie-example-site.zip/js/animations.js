/* ============================================================
   STATIC SITE TEMPLATE — animations.js (optional)
   Delete this file (and its <script> tag) if the project has
   no motion requirements.

   Behaviour:
   1. Respects prefers-reduced-motion (shows everything, no motion)
   2. If GSAP + ScrollTrigger are present, uses them
   3. Otherwise falls back to a lightweight IntersectionObserver
      that toggles the .in class on .reveal elements (CSS handles
      the transition)

   Three.js: no boilerplate included here on purpose. WebGL is a
   heavy, per-project decision. If needed, load three.js via CDN
   and add an init function following the same guard pattern.
============================================================ */

(function () {
  'use strict';

  var log = function () {
    if (window.console) console.log.apply(console, ['[anim]'].concat([].slice.call(arguments)));
  };

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  document.addEventListener('DOMContentLoaded', function () {
    var targets = document.querySelectorAll('.reveal');

    if (reduceMotion) {
      targets.forEach(function (el) { el.classList.add('in'); });
      log('Reduced motion preferred, all reveals shown immediately');
      return;
    }

    var hasGsap = typeof window.gsap !== 'undefined' && typeof window.ScrollTrigger !== 'undefined';

    if (hasGsap) {
      log('GSAP detected, using ScrollTrigger reveals');
      window.gsap.registerPlugin(window.ScrollTrigger);
      targets.forEach(function (el) {
        el.classList.add('in'); // hand visibility control to GSAP
        window.gsap.from(el, {
          y: 24,
          autoAlpha: 0,
          duration: 0.7,
          ease: 'power2.out',
          scrollTrigger: { trigger: el, start: 'top 85%' }
        });
      });
      // Add page-specific timelines below this line per project.
      return;
    }

    // Fallback: IntersectionObserver + CSS transitions
    if ('IntersectionObserver' in window) {
      log('GSAP not present, using IntersectionObserver fallback');
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.15 });
      targets.forEach(function (el) { io.observe(el); });
    } else {
      targets.forEach(function (el) { el.classList.add('in'); });
      log('No IO support, all reveals shown immediately');
    }
  });
})();
