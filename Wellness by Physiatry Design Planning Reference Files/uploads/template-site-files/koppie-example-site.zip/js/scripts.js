/* ============================================================
   STATIC SITE TEMPLATE — scripts.js
   Consent banner (Consent Mode v2), gated Microsoft Clarity,
   GA4 event tracking via dataLayer (GTM), nav toggle, and
   console.log debugging at every significant step.

   GA4 events pushed to the dataLayer (map these to GA4 tags
   in GTM with a Custom Event trigger):
     - consent_granted / consent_denied
     - nav_click        { link_label }
     - cta_click        { link_label }
     - outbound_click   { link_url, link_domain }
     - scroll_depth     { percent: 25 | 50 | 75 | 100 }
     - section_view     { section_id }
     - faq_open         { faq_question }
============================================================ */

(function () {
  'use strict';

  /* ---------------- CONFIG — TODO per project ---------------- */
  var CONFIG = {
    clarityId: 'XXXXXXXXXX',      // Microsoft Clarity project ID
    consentCookie: 'consent_choice',
    consentDays: 180,
    debug: true                    // set false in production if desired
  };

  function log() {
    if (CONFIG.debug && window.console) {
      console.log.apply(console, ['[site]'].concat([].slice.call(arguments)));
    }
  }

  log('scripts.js loaded');

  /* ---------------- Cookie helpers ---------------- */
  function setCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + days * 864e5);
    document.cookie = name + '=' + value + ';expires=' + d.toUTCString() +
      ';path=/;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : '');
  }
  function getCookie(name) {
    var m = document.cookie.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
    return m ? m[1] : null;
  }

  /* ---------------- GA4 event helper ---------------- */
  window.dataLayer = window.dataLayer || [];
  function trackEvent(eventName, params) {
    var payload = Object.assign({ event: eventName }, params || {});
    window.dataLayer.push(payload);
    log('event pushed:', eventName, params || {});
  }

  /* ---------------- Microsoft Clarity (consent-gated) ---------------- */
  var clarityLoaded = false;
  function loadClarity() {
    if (clarityLoaded || !CONFIG.clarityId || CONFIG.clarityId === 'XXXXXXXXXX') {
      log('Clarity skipped (already loaded or no ID configured)');
      return;
    }
    clarityLoaded = true;
    (function (c, l, a, r, i, t, y) {
      c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments); };
      t = l.createElement(r); t.async = 1;
      t.src = 'https://www.clarity.ms/tag/' + i;
      y = l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t, y);
    })(window, document, 'clarity', 'script', CONFIG.clarityId);
    window.clarity('consent'); // tell Clarity cookies are permitted
    log('Clarity loaded and consent signalled');
  }

  /* ---------------- Consent banner ---------------- */
  function applyConsent(choice, isNewChoice) {
    var granted = choice === 'granted';
    if (typeof window.gtag === 'function') {
      window.gtag('consent', 'update', {
        analytics_storage: granted ? 'granted' : 'denied',
        functionality_storage: granted ? 'granted' : 'denied'
      });
    }
    log('Consent Mode updated:', choice);
    if (granted) loadClarity();
    if (isNewChoice) {
      setCookie(CONFIG.consentCookie, choice, CONFIG.consentDays);
      trackEvent(granted ? 'consent_granted' : 'consent_denied');
    }
  }

  function initConsentBanner() {
    var banner = document.getElementById('consentBanner');
    var accept = document.getElementById('consentAccept');
    var decline = document.getElementById('consentDecline');
    var manage = document.getElementById('manageConsent');
    if (!banner) { log('No consent banner in DOM'); return; }

    var stored = getCookie(CONFIG.consentCookie);
    if (stored) {
      log('Existing consent choice found:', stored);
      applyConsent(stored, false);
    } else {
      banner.hidden = false;
      log('No consent choice stored, banner shown');
    }

    accept.addEventListener('click', function () {
      banner.hidden = true;
      applyConsent('granted', true);
    });
    decline.addEventListener('click', function () {
      banner.hidden = true;
      applyConsent('denied', true);
    });
    if (manage) {
      manage.addEventListener('click', function () {
        banner.hidden = false;
        log('Consent banner reopened via footer link');
      });
    }
  }

  /* ---------------- Theme toggle ----------------
     The <html data-theme> attribute is already set by the inline
     script in <head> before paint (stored choice > system > dark).
     This module just wires the button and keeps it in sync. */
  function initThemeToggle() {
    var btn = document.getElementById('themeToggle');
    var root = document.documentElement;
    if (!btn) { log('No theme toggle in DOM'); return; }

    function syncButton(theme) {
      btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    }
    syncButton(root.getAttribute('data-theme') || 'dark');

    btn.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      root.setAttribute('data-theme', next);
      syncButton(next);
      try { localStorage.setItem('theme_pref', next); } catch (e) { /* private mode etc. */ }
      log('Theme switched to:', next);
      trackEvent('theme_toggle', { theme: next });
    });

    // Live-follow the OS setting for as long as the visitor hasn't
    // made an explicit choice of their own.
    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', function (e) {
        var hasExplicitChoice = true;
        try { hasExplicitChoice = !!localStorage.getItem('theme_pref'); } catch (err) { /* ignore */ }
        if (!hasExplicitChoice) {
          var theme = e.matches ? 'light' : 'dark';
          root.setAttribute('data-theme', theme);
          syncButton(theme);
          log('System theme changed, followed:', theme);
        }
      });
    }
  }

  /* ---------------- Mobile nav ---------------- */
  function initNav() {
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('siteNav');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      log('Nav toggled:', open ? 'open' : 'closed');
    });
    // Close the menu when a link is chosen
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------------- Click tracking (data-track attributes) ---------------- */
  function initClickTracking() {
    document.addEventListener('click', function (e) {
      var el = e.target.closest('[data-track]');
      if (el) {
        trackEvent(el.getAttribute('data-track'), {
          link_label: el.getAttribute('data-label') || el.textContent.trim().slice(0, 60)
        });
      }
      // Outbound links (any anchor pointing off-site)
      var a = e.target.closest('a[href^="http"]');
      if (a && a.hostname && a.hostname !== location.hostname) {
        trackEvent('outbound_click', { link_url: a.href, link_domain: a.hostname });
      }
    });
    log('Click tracking initialised');
  }

  /* ---------------- Scroll depth ---------------- */
  function initScrollDepth() {
    var marks = [25, 50, 75, 100];
    var fired = {};
    function onScroll() {
      var doc = document.documentElement;
      var scrollable = doc.scrollHeight - window.innerHeight;
      if (scrollable <= 0) return;
      var pct = Math.round((window.scrollY / scrollable) * 100);
      marks.forEach(function (m) {
        if (pct >= m && !fired[m]) {
          fired[m] = true;
          trackEvent('scroll_depth', { percent: m });
        }
      });
      if (fired[100]) window.removeEventListener('scroll', onScroll);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    log('Scroll depth tracking initialised');
  }

  /* ---------------- Section views (IntersectionObserver) ---------------- */
  function initSectionViews() {
    if (!('IntersectionObserver' in window)) return;
    var seen = {};
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var id = entry.target.getAttribute('data-section');
        if (entry.isIntersecting && id && !seen[id]) {
          seen[id] = true;
          trackEvent('section_view', { section_id: id });
        }
      });
    }, { threshold: 0.4 });
    document.querySelectorAll('[data-section]').forEach(function (s) { io.observe(s); });
    log('Section view tracking initialised');
  }

  /* ---------------- FAQ opens ---------------- */
  function initFaqTracking() {
    document.querySelectorAll('details.faq').forEach(function (d) {
      d.addEventListener('toggle', function () {
        if (d.open) {
          var q = d.querySelector('summary');
          trackEvent('faq_open', { faq_question: q ? q.textContent.trim().slice(0, 80) : '' });
        }
      });
    });
  }

  /* ---------------- Form tracking (Formspree etc.) ----------------
     Any <form data-track-form="name"> gets:
       form_start  { form_name }  first field focused, once
       form_submit { form_name }  on submit (fires before navigation) */
  function initFormTracking() {
    document.querySelectorAll('form[data-track-form]').forEach(function (form) {
      var name = form.getAttribute('data-track-form');
      var started = false;
      form.addEventListener('focusin', function (e) {
        if (!started && e.target.matches('input, textarea, select')) {
          started = true;
          trackEvent('form_start', { form_name: name });
        }
      });
      form.addEventListener('submit', function () {
        trackEvent('form_submit', { form_name: name });
        log('Form submitted:', name);
      });
    });
    log('Form tracking initialised');
  }

  /* ---------------- PRINCIPLE 2: micro-interactions ----------------
     Images inside [data-micro="scale"] settle from slightly-large
     to true size as they enter the viewport. Deliberately subtle:
     large enough to register, small enough not to alarm anyone. */
  function initMicroScale() {
    var targets = document.querySelectorAll('[data-micro="scale"]');
    if (!targets.length) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      targets.forEach(function (el) { el.classList.add('in'); });
      log('Reduced motion, micro-scale disabled');
      return;
    }
    if (!('IntersectionObserver' in window)) {
      targets.forEach(function (el) { el.classList.add('in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    targets.forEach(function (el) { io.observe(el); });
    log('Micro-scale initialised on', targets.length, 'element(s)');
  }

  /* ---------------- Misc ---------------- */
  function initMisc() {
    var year = document.getElementById('year');
    if (year) year.textContent = new Date().getFullYear();
  }

  /* ---------------- Boot ---------------- */
  document.addEventListener('DOMContentLoaded', function () {
    log('DOM ready, initialising modules');
    initThemeToggle();
    initConsentBanner();
    initNav();
    initClickTracking();
    initScrollDepth();
    initSectionViews();
    initFaqTracking();
    initFormTracking();
    initMicroScale();
    initMisc();
    log('All modules initialised');
  });
})();
