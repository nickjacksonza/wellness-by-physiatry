# Wellness by Physiatry — Static Site Build Plan

**Status:** v1 plan, ready to build against.
**Owner:** Dr. Fabiolla Kopp / Wellness by Physiatry
**Canonical domain:** `wellnessbyphysiatry.com`
**Replaces:** the temporary Framer site at `receptive-look-689612.framer.app`
**Runs alongside:** the Elementor build at `projects.slash301.com/Clients/WellnessPhys/` — kept as a fallback, not the launch target.

---

## 0. How to use this document

| Tool | What it does with this doc |
|---|---|
| **Claude Design** (this project) | Builds page designs as `.dc.html` reference pages using the bound Wellness by Physiatry design system. `Home.dc.html` in this project is the finished pattern. |
| **Claude Code** | Owns the real repo. Reads §3–§11 as the build spec. Ports the design-system tokens to `css/tokens.css`, builds each page from §4 and §12, wires §8–§10. |
| **Claude app / WbP project** | Copy/SEO work: page titles, meta descriptions, FAQ answers, alt text. §12 is the content source map. |

Drop this file at the repo root as `PLAN.md` and add it to the WbP Claude Project knowledge so all three surfaces share one source of truth.

---

## 1. Decisions locked

| Decision | Choice |
|---|---|
| Platform | Static HTML/CSS/JS. No build step, no framework, no npm. |
| Launch set | All 14 pages, split exactly as the copy doc specifies |
| Visual system | Wellness by Physiatry design system (sage/forest, Newsreader + Manrope, arch-crop photography) |
| Code conventions | Inherited from the Koppie template: structure, accessibility, analytics, schema |
| Primary CTA | **Request an appointment** form, sitewide |
| Form handling | Formspree (or equivalent third-party POST endpoint) |
| Analytics | GTM + Consent Mode v2 default-deny, GA4 events |
| SEO | Critical — main lead source. Full schema + local SEO layer. |
| Language | English only in v1; multilingual capability stated in copy |
| Imagery | Design-system stock + placeholders until real photos arrive |
| Dropped from template | Light/dark theme toggle, Microsoft Clarity |

## 2. Open items / blockers

These are the things that will hold up launch. Ordered by urgency.

1. **Formspree account + form ID.** Nothing else can be the primary CTA until this exists. Free tier caps at 50 submissions/month.
2. **HIPAA.** A Formspree form emailing symptom detail is a PHI risk. **Recommendation:** keep the form to name, phone, email, preferred location, and a "how can we help" field with a visible notice: *"Please don't include medical details in this form."* Confirm with the clinic's compliance stance before launch.
3. **Patient portal URL** — unknown. Every "existing patients" path is a dead end until supplied. Interim: route to phone.
4. **Real photography.** Dr. Kopp headshot, Veronica headshot, both clinic locations. Highest-visibility gap on the site; stock photos of strangers undercut a physician-led clinic.
5. **Logo files.** Only a raster PNG exists. Need SVG, plus the white / mint / black variants from the Canva deck.
6. **Target keywords.** Not supplied. §9 assumes: *brain injury doctor Chicago*, *physiatrist Chicago*, *concussion specialist Chicago*, *stroke rehabilitation Chicago*, *TBI rehabilitation Chicago*, *lifestyle medicine Chicago*. Confirm or replace before titles are finalised.
7. **Hosting** undecided. §3 recommends Cloudflare Pages or Netlify — either gives free CI from Git, redirects, and HTTPS. cPanel/FTP works but loses preview deploys.
8. **Google Business Profile** — must be claimed and consistent with the address/hours/phone in the schema, or the local SEO work is wasted.
9. **Mission and Vision.** The Canva deck prints identical text for both. The copy doc has a distinct, better Vision — use the copy doc's version.
10. **Hours.** Copy doc says only "Please call to make an appointment." Real opening hours are needed for `openingHoursSpecification`.
11. **Typos in the source copy** to fix, not carry over: "Portugêse" → "Português", "spasticty" → "spasticity", "surrefergery" → "surgery", "Behaviour" → "Behavior" (US English), "Centres" → "Centers".

---

## 3. Repo layout

```
/
├── index.html                        Home
├── about.html                        About Us
├── team.html                         Meet the Team
├── mission.html                      Mission & Values
├── services.html                     Our Services (overview)
├── services/
│   ├── brain-injury-rehabilitation.html
│   ├── concussion-management.html
│   ├── lifestyle-medicine.html
│   └── physiatry-pmr.html
├── patient-resources.html            Resources overview
├── faq.html                          FAQ & Knowledge Base
├── referrals.html                    Referrals & Community
├── contact.html                      Contact Us
├── privacy.html
├── accessibility.html
├── 404.html
├── css/
│   ├── tokens.css                    ← ported from the design system, verbatim
│   └── styles.css                    layout + components
├── js/
│   ├── scripts.js                    nav, consent, GA4 events, form
│   └── animations.js                 reveal on entry, reduced-motion guarded
├── assets/
│   ├── logo/                         wbp-umbrella-logo.svg + png fallbacks
│   ├── conditions/                   5 leaf icons
│   └── photography/                  arch-crop portraits + feature photos
├── sitemap.xml
├── robots.txt
├── llms.txt
├── .well-known/security.txt
└── PLAN.md
```

**Hosting:** Cloudflare Pages or Netlify, deploying from `main`. Redirect the Framer URL and all old Framer paths to the new equivalents; 301, not 302.

**No build step is a hard constraint.** It means every page repeats its own header and footer markup. Accept the duplication — it is the price of zero tooling. When a nav item changes, it changes in 15 files; that is a find-and-replace, and Claude Code does it in one pass.

---

## 4. Sitemap and page specs

14 pages. `H1` and `H2` are verbatim from the copy doc. Titles are drafts — confirm against the final keyword list.

| # | URL | Nav label | H1 | Title tag (draft) |
|---|---|---|---|---|
| 1 | `/` | Home | Healing for Your Brain and Body with Respect, Care, and Hope | Brain Injury Rehabilitation & Physiatry in Chicago \| Wellness by Physiatry |
| 2 | `/about.html` | About Us | Dedicated to Your Recovery Journey and Long-Lasting Results | About Wellness by Physiatry \| Physician-Led Neurorehab, Chicago |
| 3 | `/team.html` | Meet the Team | Meet the Team Behind Your Recovery | Dr. Fabiolla Kopp, MD \| Physiatrist & Brain Injury Specialist, Chicago |
| 4 | `/mission.html` | Mission & Values | Our Chicago-Based Mission & Values | Mission & Values \| Culturally Competent, Multilingual Care |
| 5 | `/services.html` | Our Services | Specialized Treatment Rooted in Clarity and Compassion | Brain Injury & Lifestyle Medicine Services \| Chicago |
| 6 | `/services/brain-injury-rehabilitation.html` | Brain Trauma & Stroke | Regain Independence with Expert Brain Injury Medicine Rehabilitation | TBI & Stroke Rehabilitation Chicago \| Spasticity, Dysphagia, Memory |
| 7 | `/services/concussion-management.html` | Concussion Management | Specialized Care for Concussions and Persistent Symptoms | Concussion Specialist Chicago \| Post-Concussion Symptom Care |
| 8 | `/services/lifestyle-medicine.html` | Lifestyle Medicine | Whole-Person Healing Through Sustainable Healthy Habits | Lifestyle Medicine & Group Sessions \| Chicago Brain Injury Recovery |
| 9 | `/services/physiatry-pmr.html` | Physiatry & PM&R | Expert Physical Medicine and Rehabilitation Guided by Science | Physiatrist in Chicago \| Physical Medicine & Rehabilitation (PM&R) |
| 10 | `/patient-resources.html` | Patient Resources | Resources and Tools to Support Your Healing Journey | Patient Resources \| Wellness by Physiatry |
| 11 | `/faq.html` | FAQs | Answers to Common Questions About Your Recovery | FAQ \| Insurance, First Visit & Your Diagnosis |
| 12 | `/referrals.html` | Referrals | Connecting You to a Village of Trusted Care | Therapy Referrals & Community Support \| Chicago |
| 13 | `/contact.html` | Contact Us | Begin Your Health Journey Today | Contact & Locations \| Michigan Ave & Southport, Chicago |
| 14 | `/privacy.html`, `/accessibility.html`, `/404.html` | footer only | — | — |

### Navigation

Chunked to 5 destinations plus one CTA. Sub-pages live in dropdowns from About, Services, and Resources.

```
Home | About Us ▾ | Our Services ▾ | Patient Resources ▾ | Contact  [Request an appointment]
```

Dropdown contents:
- **About Us** → Our Story, Meet the Team, Mission & Values
- **Our Services** → Overview, Brain Trauma & Stroke, Concussion Management, Lifestyle Medicine, Physiatry & PM&R
- **Patient Resources** → Overview, FAQs, Referrals & Community

Rules from the template that hold here: logo top-left links home; nav top-right; hamburger top-right on mobile (not moved to the thumb zone); plain-word labels only. On mobile the dropdowns become an accordion inside the drawer — never a nested flyout.

### Page rhythm

Every content page follows the same skeleton, which is also the copy doc's structure:

1. **Page hero** — eyebrow, H1, one lead paragraph, primary CTA. Arch-crop photo right on ≥900px.
2. **H2 section** — the elaboration paragraph, max 640px measure.
3. **Three H3 blocks** — the copy doc gives exactly three per page. Cards on service pages, prose sections on About/Resources.
4. **Cross-links** — 2–3 cards to sibling pages.
5. **CTA band** — sage field, one line of reassurance, appointment form link + phone.

Deviations: Home adds the conditions strip, an FAQ trio, and the two locations. Contact swaps §3 for the form + locations + transit. FAQ swaps §3 for the accordion set.

---

## 5. Design tokens → CSS

Copy the four design-system token files into a single `css/tokens.css` **without editing values**. Every rule in `styles.css` references `var(--*)`; no raw hex in the stylesheet.

Reference values (source: the design system's `tokens/`):

```css
--color-sage-500: #bbcd6f;    /* primary brand */
--color-forest-700: #536f58;  /* body text, buttons, wordmark */
--color-forest-900: #35462f;
--color-cream: #fbf8f1;       /* page background — never stark white */
--color-ink: #2f3a2c;
--color-ink-soft: #5a6455;

/* condition accents — one hue per condition, never general decoration */
--condition-tbi: #fadd8b;              /* gold */
--condition-stroke: #bbcd6f;           /* sage */
--condition-concussion: #e8c58f;       /* sand */
--condition-cognitive: #536f58;        /* forest */
--condition-neurobehavioral: #66a4a8;  /* teal */

--font-display: 'Newsreader', Georgia, serif;   /* headlines, pull quotes */
--font-body: 'Manrope', -apple-system, sans-serif;

--radius-md: 12px; --radius-lg: 20px; --radius-pill: 999px;
--radius-arch: 999px 999px 0 0;   /* signature photo crop */
--shadow-md: 0 8px 24px rgba(83,111,88,.12);
```

Non-negotiables carried from the design system:

- Cream page background. White only for card surfaces.
- Max **two** background colors active per page (cream + one accent tint).
- Mint `#5cff7f` is a vital accent — focus rings, one stat, one badge. Never a background field.
- Arch-top crop (`border-radius: var(--radius-arch)`) on every portrait and feature photo. This is the brand's signature; a plain rectangle is a mistake.
- Borders are rare and low-contrast. Separation comes from spacing and color blocking.
- Shadows are sage/forest-tinted, never gray.
- Sections breathe: 64–96px vertical padding, 1200px max content width.
- No gradients, no texture, no full-bleed photo behind text, no blur, no emoji.

**Fonts:** self-host Newsreader and Manrope as woff2 with `font-display: swap` rather than hitting the Google Fonts CDN. Cuts a third-party request and a privacy question. Subset to Latin.

---

## 6. Component inventory

Static HTML/CSS equivalents of the design-system components. Each maps to a `.dc.html` block in `Home.dc.html`.

| Component | Class | Where | Notes |
|---|---|---|---|
| Header + nav | `.site-header`, `.site-nav` | all | dropdowns, mobile drawer, skip link |
| Hero | `.hero` | all | eyebrow + H1 + lead + 2 buttons + arch photo |
| Button | `.btn.btn-primary` / `.btn-secondary` / `.btn-ghost` | all | pill, `translateY(-1px)` on hover |
| Section heading | `.section-heading` | all | eyebrow + H2 + subtitle, 640px max |
| Condition tag | `.condition-tag` | Home, service pages | leaf icon on tinted circle + label |
| Service card | `.service-card` | Home, Services | 4:5 arch-crop photo, H3, copy, text link |
| Team card | `.team-card` | Team, About | arch-crop portrait, name, credential, bio |
| FAQ item | `.faq` | Home, FAQ | native `<details>`/`<summary>` — free keyboard access |
| Contact card | `.contact-card` | Contact, footer | address, transit, parking, map link |
| CTA band | `.cta-band` | all | sage field, reassurance line, form + phone |
| Footer | `.site-footer` | all | address left, links middle, hours right, legal beneath |
| Pull quote | `.pull-quote` | About, Team | Newsreader italic — Dr. Kopp's own voice |

**Voice reminder for anyone writing new copy:** *I* when Dr. Kopp speaks personally (About, Team, bios), *we* when the clinic speaks (Home, Services). Always *you* for the reader. Sentence case. No hype, no fear framing, no clinical distancing.

---

## 7. Motion

Small dose, hover or entry only, nothing that moves what someone is reading. Every effect wrapped in `@media (prefers-reduced-motion: no-preference)`.

| Effect | Where | Amount |
|---|---|---|
| Button lift | all CTAs | `translateY(-1px)`, 150ms |
| Arrow nudge | primary CTAs | 3px forward on hover |
| Card lift + photo scale | service/team cards | 4px lift, `scale(1.03)` |
| Nav underline from centre | header links | 200ms |
| Photo settle on entry | hero, feature photos | `1.05 → 1.0` over ~800ms |
| Section reveal | below-fold sections | 12px rise + fade, IntersectionObserver |

Cap it there. Doubling any value tips a calm clinical site into an alarming one, and this audience includes people with post-concussion vestibular symptoms — for whom motion is a medical issue, not a taste one. Honour reduced-motion absolutely.

---

## 8. Analytics and consent

Lifted wholesale from the template.

1. Consent Mode v2 defaults set to **denied** in `<head>` before GTM, `wait_for_update: 500`.
2. GTM container loads after the defaults.
3. Cookie banner: Accept / Decline, choice stored in a `consent_choice` cookie, restored on load. Footer "Cookie settings" reopens it.
4. GA4 events via `data-track` attributes, delegated in `scripts.js`:

| Event | Trigger |
|---|---|
| `nav_click` | header, footer, dropdown links |
| `cta_click` | every button and phone/email link (`data-label` identifies it) |
| `form_start` / `form_submit` | appointment form |
| `faq_open` | `<details>` toggle |
| `scroll_depth` | 25 / 50 / 75 / 100% |
| `section_view` | `data-section` enters viewport |
| `outbound_click` | portal, maps, referral partners |

Drop from the template: Clarity (session recording on a clinic site invites a HIPAA argument nobody needs), and the light/dark toggle (the brand has one palette).

---

## 9. SEO layer

SEO is the main lead source, so this is the highest-leverage section of the build.

**Per page:** unique `<title>` under 60 chars, meta description 140–160, `<link rel="canonical">`, Open Graph + Twitter card, one `<h1>`, no skipped heading levels, descriptive alt text on every image, `BreadcrumbList` JSON-LD.

**Sitewide JSON-LD**, `@id`-linked so the entities join up:

- `MedicalClinic` (`#org`) — name, url, logo, telephone `+17733124423`, email, `medicalSpecialty: PhysicalMedicineAndRehabilitation`, `availableLanguage: [en, es, pt]`, `openingHoursSpecification`, `sameAs` for social/GBP.
- Two `MedicalClinic` location nodes with `PostalAddress` + `geo`:
  - Downtown — 30 N Michigan Ave, Chicago, IL 60602
  - North Side — 2555 N Southport Ave, Chicago, IL 60614
- `Physician` (`#drkopp`) — Fabiolla Kopp, MD, `medicalSpecialty`, `alumniOf`/`worksFor`, `knowsLanguage`.
- `MedicalWebPage` + `MedicalCondition` on each service page (TBI, Stroke, Concussion, Cognitive changes, Neurobehavioral changes).
- `FAQPage` on `/faq.html` and on the Home FAQ trio — both the current FAQ and the "New FAQs for Page & Schema.org" set in the copy doc are written for exactly this.
- `Service` nodes on each service page, `provider` → `#org`.

**Local SEO:** NAP identical on every page and in Google Business Profile. City + specialty in H1/title where it reads naturally. Location pages carry transit and parking detail (already written in the copy doc) — that content genuinely earns local rankings.

**Files:** `sitemap.xml` with all 14 URLs, `robots.txt` pointing to it, `llms.txt` summarising the clinic for AI crawlers.

**Assumed keyword targets** (confirm — see §2.6): brain injury doctor Chicago, physiatrist Chicago, concussion specialist Chicago, stroke rehabilitation Chicago, TBI rehabilitation Chicago, lifestyle medicine physician Chicago, multilingual brain injury care Chicago.

---

## 10. Appointment form

The primary CTA sitewide. Lives on `/contact.html`, linked from every header, CTA band, and footer.

Chunked to the minimum that lets the clinic call back:

1. Name
2. Phone
3. Email
4. Preferred location (Michigan Ave / Southport / either)
5. New or existing patient
6. How can we help? — with the no-medical-details notice

Labels above fields, submit bottom-left, inline validation on blur, a real success state on the same page (no redirect to a bare "thanks" page). `POST` to Formspree with a honeypot field. Phone number chunked as `(773) 312-4423` and `tel:`-linked everywhere it appears.

Until the portal URL exists, the "existing patient" path shows the phone number rather than a broken link.

---

## 11. Accessibility and performance

**Accessibility** — this audience includes people with cognitive, visual, and vestibular impairment, so treat WCAG 2.2 AA as the floor, not the goal.

- Skip link first in the DOM.
- Body text ≥17px, line height 1.6, measure ≤70 characters.
- Verify contrast: sage `#bbcd6f` needs forest-900 text on it, never white.
- Visible focus rings everywhere — mint `#5cff7f` is the accent that earns its place here.
- Keyboard-operable nav dropdowns; `aria-expanded` on all toggles.
- `<details>` for FAQs rather than a custom accordion.
- Honour `prefers-reduced-motion`.
- Published accessibility statement at `/accessibility.html`.

**Performance** — target Lighthouse 95+ on mobile.

- AVIF with JPEG fallback via `<picture>`; explicit `width`/`height` on every image to prevent layout shift.
- Hero image `fetchpriority="high"` and preloaded; everything below the fold `loading="lazy"`.
- Self-hosted subset woff2 fonts.
- One CSS file, two deferred JS files. No jQuery, no icon font, no carousel library.

---

## 12. Content source map

All copy comes from `V2 Working Copy Doc for Wellness by Physiatry.md`. Nothing gets rewritten without the clinic's sign-off; the doc's own bracketed notes mark the only genuine gaps.

| Page | Copy doc section | Gaps to fill |
|---|---|---|
| Home | "1 Home" (end of doc) | Which 3 FAQs to feature; hero photo |
| About | "About Us" → Our Story | Doc asks "what's the ideal word count?" — answer: ~350 on the page, with the longer version on Team |
| Team | Dr. Kopp bio + "Veronica – Clinic Coordinator" | Both headshots; Dr. Kopp's credentials line |
| Mission & Values | Our Mission / Our Vision | Use the copy doc's Vision, not the Canva deck's duplicate |
| Services | "3 Our Services (Overview)" | — |
| Brain Trauma & Stroke | "3a" | — |
| Concussion | "3b" | — |
| Lifestyle Medicine | "3c" | — |
| Physiatry & PM&R | H1/H2/H3s only | **Body copy not written.** Three H3s exist; needs ~150 words each |
| Patient Resources | "4 Patient Resources" | — |
| FAQ | Current FAQ + "New FAQs for Page & Schema.org" | Doc notes "add more info / form requirements" under First Visit |
| Referrals | "4b" | Named partner organisations, if any can be listed |
| Contact | "5 Contact Us" | Real hours; portal URL; embedded or static map |
| Privacy / Accessibility | not written | Standard copy, clinic to review |

---

## 13. Build order

| Phase | Work | Done when |
|---|---|---|
| **1. Foundation** | Repo, `tokens.css`, `styles.css` shell, header/footer/CTA-band partial markup, fonts self-hosted, consent + GA4 in place | Header and footer render correctly on a blank page |
| **2. Reference page** | `index.html` built from `Home.dc.html` — every component appears here once | Home passes Lighthouse 95+, validates, schema clean |
| **3. Templates** | One service page (`brain-injury-rehabilitation.html`) and one prose page (`about.html`) as the two patterns everything else copies | Both pass the same checks |
| **4. Fill** | Remaining 10 pages by copy-paste from the two templates + §12 copy | All 14 URLs live, nav complete, no orphans |
| **5. Systems** | Form live on Formspree, full schema graph, sitemap/robots/llms.txt, 404, privacy, accessibility statement | Rich Results Test clean on Home, a service page, and FAQ |
| **6. Pre-launch** | Real photos swapped in, hours confirmed, portal linked, keyboard + screen-reader pass, 301 map from Framer URLs, GBP alignment | QA checklist below fully green |

Phase 2 is the one that matters. Get Home genuinely right and phases 3–4 are mechanical.

## 14. QA checklist

- [ ] One `<h1>` per page, no skipped heading levels
- [ ] Unique title + meta description on all 14 pages
- [ ] Canonical on every page; sitemap matches live URLs exactly
- [ ] Schema passes Google Rich Results Test with no warnings
- [ ] NAP identical across site, schema, and Google Business Profile
- [ ] Every image has meaningful alt text and explicit dimensions
- [ ] Full keyboard pass: nav dropdowns, mobile drawer, form, FAQs
- [ ] Contrast checked on sage and sand fields
- [ ] Reduced-motion honoured
- [ ] Form submits, honeypot works, success state visible, `form_submit` fires
- [ ] Consent default-deny verified in GA4 debug view; Decline blocks analytics
- [ ] No broken links; 404 offers two clear ways back
- [ ] Mobile 360px through desktop 1920px, no horizontal scroll
- [ ] Lighthouse ≥95 performance / 100 accessibility on mobile
- [ ] 301s from every old Framer path
